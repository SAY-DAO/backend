"""empty message

Revision ID: 73042ee51024
Revises: 1927cbecc60d, 6298870eb1df
Create Date: 2020-02-19 16:21:35.751173

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '73042ee51024'
down_revision = ('1927cbecc60d', '6298870eb1df')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
