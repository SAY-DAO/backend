"""empty message

Revision ID: 40570cef36d8
Revises: 5f6dcf3000eb, 73042ee51024
Create Date: 2020-02-23 14:44:30.604572

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '40570cef36d8'
down_revision = ('5f6dcf3000eb', '73042ee51024')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
