"""empty message

Revision ID: 18e8746efd3f
Revises: f109ef26bc91, bb2076063329
Create Date: 2020-01-30 02:44:13.063253

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '18e8746efd3f'
down_revision = ('f109ef26bc91', 'bb2076063329')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
