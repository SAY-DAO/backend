"""empty message

Revision ID: 98b0f899d267
Revises: 133ac22dd633, ff3c9da75110
Create Date: 2020-01-26 17:24:05.465168

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '98b0f899d267'
down_revision = ('133ac22dd633', 'ff3c9da75110')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
