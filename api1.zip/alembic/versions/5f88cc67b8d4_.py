"""empty message

Revision ID: 5f88cc67b8d4
Revises: 1d93da5f70f7, 6d3d0ec12513
Create Date: 2020-02-12 15:42:13.850630

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5f88cc67b8d4'
down_revision = ('1d93da5f70f7', '6d3d0ec12513')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
