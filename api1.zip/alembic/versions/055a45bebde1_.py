"""empty message

Revision ID: 055a45bebde1
Revises: 7edc4b2ac178, 98472bc803ca
Create Date: 2020-02-01 19:04:04.632815

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '055a45bebde1'
down_revision = ('7edc4b2ac178', '98472bc803ca')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
