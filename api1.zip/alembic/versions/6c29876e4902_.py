"""empty message

Revision ID: 6c29876e4902
Revises: 3d3ba76769d7
Create Date: 2020-01-14 19:42:05.132995

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '6c29876e4902'
down_revision = '3d3ba76769d7'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
