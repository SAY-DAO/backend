"""empty message

Revision ID: 7edc4b2ac178
Revises: ff464a474c47, 18e8746efd3f
Create Date: 2020-01-30 21:41:25.455474

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7edc4b2ac178'
down_revision = ('ff464a474c47', '18e8746efd3f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
