"""empty message

Revision ID: 1d93da5f70f7
Revises: 56a3abfdf12b, 99afe9e2e647
Create Date: 2020-02-08 20:12:25.061393

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1d93da5f70f7'
down_revision = ('56a3abfdf12b', '99afe9e2e647')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
