import enum


class Gender(enum.Enum):
    female = 'female'
    male = 'male'
    other = 'other'

