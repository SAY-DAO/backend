class LANGS:
    en = 'en'
    fa = 'fa'

