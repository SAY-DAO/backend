class ContentFA:
    CONFIRM_PHONE = '%s کد تایید شش رقمی شما در SAY است.'
    RESET_PASSWORD = 'برای تغییر گذرواژه روی لینک زیر کلیک کنید.\n%s'
