class ContentEN:
    # TODO: pending content
    CONFIRM_PHONE = 'SAY verification code:\n %s'
    RESET_PASSWORD = 'Click on the link below to change your password.\n%s'

