from decimal import Decimal
from datetime import datetime, timedelta

from khayyam import JalaliDate
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import HSTORE
from sqlalchemy.orm import object_session
from sqlalchemy import event

from say.statuses import NeedStatuses
from say.tasks import send_email, send_embeded_subject_email
from say.render_template_i18n import render_template_i18n

from .payment_model import Payment
from .need_family_model import NeedFamily
from .user_model import User
from . import *

"""
Need Model
"""


class Need(base, Timestamp):
    __tablename__ = "need"

    id = Column(Integer, nullable=False, primary_key=True, unique=True)

    child_id = Column(Integer, ForeignKey('child.id'))

    name_translations = Column(HSTORE)
    name = translation_hybrid(name_translations)

    description_translations = Column(HSTORE)
    description = translation_hybrid(description_translations)

    imageUrl = Column(String, nullable=False)
    category = Column(Integer, nullable=False)  # 0:Growth | 1:Joy | 2:Health | 3:Surroundings
    isUrgent = Column(Boolean, nullable=False)
    details = Column(Text, nullable=True)
    _cost = Column(Integer, nullable=False)
    purchase_cost = Column(Integer, nullable=False, default=0)
    paid = Column(Integer, nullable=False, default=0)
    donated = Column(Integer, nullable=False, default=0)
    link = Column(String, nullable=True)
    affiliateLinkUrl = Column(String, nullable=True)
    isDone = Column(Boolean, nullable=False, default=False)
    isDeleted = Column(Boolean, nullable=False, default=False)
    receipts = Column(String, nullable=True)  # comma separated
    isConfirmed = Column(Boolean, nullable=False, default=False)
    confirmUser = Column(Integer, nullable=True)
    type = Column(Integer, nullable=False)  # 0:service | 1:product
    doing_duration = Column(Integer, nullable=False, default=5)
    status = Column(Integer, nullable=False, default=0)
    status_updated_at = Column(DateTime, nullable=True)
    isReported = Column(Boolean, default=False)
    img = Column(Text, nullable=True)
    title = Column(Text, nullable=True)
    oncePurchased = Column(Boolean, nullable=False, default=False)
    bank_track_id = Column(Unicode(30), nullable=True) # Only for services
    # Dates:
    doneAt = Column(DateTime, nullable=True)
    purchase_date = Column(DateTime)
    expected_delivery_date = Column(DateTime)
    ngo_delivery_date = Column(DateTime)
    child_delivery_date = Column(DateTime)
    confirmDate = Column(DateTime, nullable=True)

    # TODO: Change this to @observers
    @hybrid_property
    def childSayName(self):
        return self.child.sayName

    @childSayName.expression
    def childSayName(cls):
        pass

    def _set_cost(self, cost):
        cost = int(str(cost).replace(',', ''))
        self._cost = cost

    def _get_cost(self):
        return self._cost

    cost = synonym(
        '_cost',
        descriptor=property(_get_cost, _set_cost),
    )

    @hybrid_property
    def pretty_cost(self):
        return int_formatter(self.cost)

    # TODO: proper expression
    @pretty_cost.expression
    def pretty_cost(cls):
        pass

    @hybrid_property
    def pretty_paid(self):
        return int_formatter(self.paid)

    # TODO: proper expression
    @pretty_paid.expression
    def pretty_paid(cls):
        pass

    @hybrid_property
    def pretty_donated(self):
        return int_formatter(self.donated)

    # TODO: proper expression
    @pretty_paid.expression
    def pretty_donated(self):
        pass

    @hybrid_property
    def progress(self):
        if self.isDone:
            return 100

        try:
           return str(format(self.paid / self.cost * 100, '.1f')) \
               .rstrip('0') \
               .rstrip('.')

        except:
            return 0

    @progress.expression
    def progress(cls):
        return cls.paid / cls.cost * 100

    @hybrid_property
    def isDone(self):
        return self.status >= 2

    '''
    aggregated generates query like this:
    UPDATE need SET paid=(
        SELECT coalesce(
            sum(payment.need_amount),
            , 0
        ) AS coalesce_1
        FROM payment
        WHERE need.id = payment.id_need AND payment.verified IS NOT NULL)
    WHERE need.id IN (502);
    '''
    @aggregated('payments', Column(Integer, nullable=False, default=0))
    def paid(cls):
        from . import Payment
        return coalesce(
            func.sum(Payment.need_amount),
            0,
        )

    @aggregated('payments', Column(Integer, nullable=False, default=0))
    def donated(cls):
        from . import Payment
        return coalesce(
            func.sum(Payment.donation_amount),
            0,
        )

    @observes('payments.verified')
    def payments_observer(self, _):
        session = object_session(self)
        if self.status is None or self.status > 2:
            return

        paid = sum(
            payment.need_amount if payment.verified else 0
            for payment in self.payments
        )

        if paid == 0:
            self.status = 0

        elif paid < self.cost:
            self.status = 1

        elif paid == self.cost:
            self.done()

    @hybrid_property
    def type_name(self):
        if self.type == 0:
            return 'service'
        elif self.type == 1:
            return 'product'

        return 'unknown'

    @type_name.expression
    def type_name(cls):
        pass

    @hybrid_property
    def status_description(self):
        locale = get_locale()
        raw_status = NeedStatuses.get(self.status, self.type_name, locale)

        if self.status == 2 or (self.type == 1 and self.status == 3):
            '''
            p2s2p3 need status condition
            تمام هزینه سرویس/کالا پرداخت شده است
            کالا خریداری شده است و به زودی توسط دیجی‌کالا به انجمن می‌رسد
            '''
            return raw_status % self.name

        elif (self.type == 1 and self.status == 5) or (self.type == 0 and self.status == 4):
            '''
            p5s4 need status condition
            کالا به دست اصغر رسید
            هزینه سرویس برای اصغر تمام و کمال پرداخت شد
            '''
            return raw_status % (self.name, self.childSayName)

        elif self.type == 0 and self.status == 3:
            '''
            s3 need status condition
            مبلغ 2000 تومان به حساب انجمن واریز شده است تا هزینه سرویس پرداخت شود
            '''
            return raw_status % (self.pretty_cost, self.name)

    @status_description.expression
    def status_description(cls):
        pass

    child = relationship(
        'Child',
        foreign_keys=child_id,
        uselist=False,
        back_populates='needs',
        lazy='selectin',
    )

    payments = relationship(
        'Payment',
        back_populates='need',
        primaryjoin=
            'and_(Need.id==Payment.id_need, Payment.verified.isnot(None))',
    )

    participants = relationship(
        'NeedFamily',
        back_populates='need',
        lazy='selectin',
    )

    def done(self):
        self.status = 2
        self.doneAt = datetime.utcnow()

    @property
    def family(self):
        return {
            member.user
            for member in self.child.family.current_members()
        }

    def refund_extra_credit(self):
        session = object_session(self)
        total_refund = Decimal(self.paid) - Decimal(self.purchase_cost)

        participants =  session.query(NeedFamily) \
            .filter(NeedFamily.id_need == self.id)

        for participant in participants:

            participation_ratio = Decimal(participant.paid) / Decimal(self.paid)

            refund_amount = Decimal(participation_ratio) * Decimal(total_refund)

            if refund_amount <= 0:
                continue

            refund_payment = Payment(
                need=self,
                user=participant.user,
                need_amount=-refund_amount,
                credit_amount=-refund_amount,
                desc='Refund payment',
            )

            self.payments.append(refund_payment)
            refund_payment.verify()

        session.flush()

        return

    def say_extra_payment(self):
        extra_cost = self.purchase_cost - self.paid

        session = object_session(self)
        say_user = session.query(User) \
            .filter_by(userName='SAY') \
            .one()

        say_payment = Payment(
            need=self,
            user=say_user,
            need_amount=extra_cost,
            desc='SAY payment',
        )

        self.payments.append(say_payment)
        say_payment.verify(is_say=True)

        return

    @property
    def current_participants(self):
        for p in self.participants:
            if p.isDeleted:
                continue

            yield p

        past_participation, = session.query(
            func.sum(NeedFamily.paid)
        ) \
            .filter(NeedFamily.id_need==self.id) \
            .filter(NeedFamily.isDeleted==True) \
            .first()

        if past_participation:
            yield NeedFamily(
                user_role=-1,
                paid=past_participation,
            )

    def update(self):
        from say.utils import digikala
        data = digikala.get_data(self.link)

        dkp = data['dkp']
        img = data['img']
        title = data['title']
        cost = data['cost']

        if img:
            self.img = img

        if title:
            self.title = title

        if cost and not self.isDone:
            if type(cost) is int:
                self.cost = cost
                self.purchase_cost = cost

            elif type(cost) is str:
                session = object_session(self)

                from say.api import app
                from say.models import Ngo

                SAY_ngo = session.query(Ngo).filter_by(name='SAY').first()
                if self.child.ngo.name != SAY_ngo.name:
                    with app.app_context():
                        send_email.delay(
                            subject=f'تغییر وضعیت کالا {dkp}',
                            to=SAY_ngo.coordinator.emailAddress,
                            html=render_template_i18n(
                                'product_status_changed.html',
                                child=self.child,
                                need=self,
                                dkp=dkp,
                                details=cost,
                            ),
                        )
        return data

    def child_delivery_product(self):
        from say.api import app
        from say.tasks.update_needs import change_need_status_to_delivered

        deliver_to_child_delay = datetime.utcnow() \
            + timedelta(seconds=app.config['DELIVER_TO_CHILD_DELAY'])

        change_need_status_to_delivered.apply_async(
            (self.id,),
            eta=deliver_to_child_delay,
        )


@event.listens_for(Need.status, "set")
def status_event(need, new_status, old_status, initiator):

    if new_status == 4 and need.isReported != True:
        raise Exception('Need has not been reported to ngo yet')

    need.status_updated_at = datetime.utcnow()

    if need.type == 0:  # Service
        if new_status == 3:
            need.ngo_delivery_date = datetime.utcnow()

        elif new_status == 4:
            need.child_delivery_date = datetime.utcnow()

    elif need.type == 1:  # Product
        if new_status == 3:
            need.purchase_date = datetime.utcnow()

        elif new_status == 4:
            if old_status == new_status:
                return

            need.ngo_delivery_date = parse_datetime(
                request.form.get('ngo_delivery_date')
            )

            if not (
                need.expected_delivery_date
                <= need.ngo_delivery_date <=
                datetime.utcnow()
            ):
                raise Exception('Invalid ngo_delivery_date')

            need.child_delivery_product()

            if need.purchase_cost < need.paid:
                need.refund_extra_credit()

            elif need.purchase_cost > need.paid:
                need.say_extra_payment()

            need.cost = need.purchase_cost

