SUPER_ADMIN = 'super admin'
SOCIAL_WORKER = 'social worker'
COORDINATOR = 'coordinator'
NGO_SUPERVISOR = 'NGO supervisor'
SAY_SUPERVISOR = 'SAY supervisor'
ADMIN = 'admin'
USER = 'user'

